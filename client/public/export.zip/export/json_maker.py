import json

TILE_SIZE = 100

def is_overlapping(tile_a, tile_b):
    return not (
        tile_a["x"] + TILE_SIZE <= tile_b["x"] or
        tile_b["x"] + TILE_SIZE <= tile_a["x"] or
        tile_a["y"] + TILE_SIZE <= tile_b["y"] or
        tile_b["y"] + TILE_SIZE <= tile_a["y"]
    )

def compute_tile_visibility_and_reveals(tiles):
    for i, tile in enumerate(tiles):
        tile["revealed"] = True
        tile["reveals"] = []

        for j in range(i + 1, len(tiles)):
            other = tiles[j]
            if other["status"] != 0:
                continue
            if is_overlapping(tile, other):
                tile["revealed"] = False
                break

    for i, tile in enumerate(tiles):
        hidden_by_tile = []
        for j in range(i):
            other = tiles[j]
            if other["status"] != 0 or other["revealed"]:
                continue
            if is_overlapping(tile, other):
                hidden_by_tile.append(other["id"])
        tile["reveals"] = hidden_by_tile

    return tiles

with open("scene.json", "r") as f:
    tile_data = json.load(f)

updated_tiles = compute_tile_visibility_and_reveals(tile_data)

with open("scene_with_visibility.json", "w") as f:
    json.dump(updated_tiles, f, indent=2)